SmartPay Wallet Demo - Android Studio Project

महत्त्वाचे:
हा Android Studio source project आहे; या वातावरणात Android SDK/Gradle build साधने उपलब्ध नसल्यामुळे थेट install करता येणारी APK binary तयार/चाचणी करता आलेली नाही.

APK तयार करण्याची पद्धत:
1. संगणकावर Android Studio स्थापित करा.
2. हा ZIP Extract करा.
3. Android Studio > Open > Extract केलेला SmartPay_Android_Project folder निवडा.
4. Gradle Sync पूर्ण होऊ द्या. आवश्यक Android SDK Platform 35 install करण्यास सांगितल्यास install करा.
5. Build > Build Bundle(s) / APK(s) > Build APK(s) निवडा.
6. Build पूर्ण झाल्यावर app/build/outputs/apk/debug/app-debug.apk येथे APK मिळेल.
7. APK Android फोनमध्ये पाठवून install करा. फोनमध्ये विचारल्यास त्या स्रोतासाठी Install unknown apps परवानगी द्या.

Admin Demo Login:
Email: admin@smartpay.demo
Password: admin123

Demo user account नोंदणी करून तयार करता येईल.

मर्यादा व सुरक्षा:
- हे फक्त शैक्षणिक Demo Wallet आहे. खरे पैसे/UPI/बँक व्यवहार नाहीत.
- माहिती त्या फोनच्या WebView local storage मध्ये राहते; cloud sync नाही.
- Passwords स्थानिक browser storage मध्ये plain text स्वरूपात असतात. वास्तविक पासवर्ड वापरू नका.
- हा source production वापरासाठी सुरक्षित नाही. सार्वजनिक वितरणापूर्वी backend, सुरक्षित authentication, server-side authorization, data protection, security testing व कायदेशीर अनुपालन आवश्यक आहे.
